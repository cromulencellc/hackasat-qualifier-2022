#!/bin/bash

./starlunk ShippyMcShipFace Honolulu gateways.csv sats.csv users.csv
